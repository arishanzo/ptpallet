<p><strong>Nama:</strong> <?php echo e($data['name']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Pesan:</strong></p>
<p><?php echo nl2br(e($data['message'])); ?></p>
<?php /**PATH C:\project\ptpallet\resources\views/emails/contact.blade.php ENDPATH**/ ?>