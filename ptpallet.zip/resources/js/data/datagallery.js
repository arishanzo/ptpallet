const getDataGallery = () => ([
     { id: 1, 
      category: 'Training', 
      img: './img/gallery/photo1.jpg',
    },


    { id: 2, 
    category: 'Training', 
        img: './img/gallery/photo2.jpg',
    },

    { id: 3,
        category: 'Training', 
       img: './img/gallery/photo3.jpg',
    
    },

    { id: 4, 
    category: 'Training', 
       img: './img/gallery/photo4.jpg',
  
    },

     { id: 5, 
     category: 'Training', 
     img: './img/gallery/photo5.jpg',
     },

     
     { id: 6, 
     category: 'Training', 
     img: './img/gallery/photo6.jpg',
     },


       
     { id: 7, 
     category: 'Training', 
     img: './img/gallery/photo7.jpg',
     },

       
     { id: 8, 
     category: 'Training', 
     img: './img/gallery/photo8.jpg',
     },

       
     { id: 9, 
     category: 'Training', 
     img: './img/gallery/photo9.jpg',
     },


     
     { id: 10, 
     category: 'Produk', 
     img: './img/gallery/produk1.jpg',
     },

      
     { id: 11, 
     category: 'Produk', 
     img: './img/gallery/produk2.jpg',
     },

      
     { id: 12, 
     category: 'Produk', 
     img: './img/gallery/produk3.jpg',
     },

      
     { id: 13, 
     category: 'Produk', 
     img: './img/gallery/produk4.jpg',
     },

      
     { id: 14, 
     category: 'Produk', 
     img: './img/gallery/produk5.jpg',
     },

      
     { id: 15, 
     category: 'Produk', 
     img: './img/gallery/produk6.jpg',
     },

      
     { id: 16, 
     category: 'Produk', 
     img: './img/gallery/produk7.jpg',
     },

      
     { id: 17, 
     category: 'Produk', 
     img: './img/gallery/produk8.jpg',
     },

      
     { id: 18, 
     category: 'Produk', 
     img: './img/gallery/produk9.jpg',
     },

      
     { id: 19, 
     category: 'Workshop', 
     img: './img/gallery/workshop.jpg',
     },

        { id: 20, 
     category: 'Workshop', 
     img: './img/gallery/Picture1.jpg',
     },

         { id: 21, 
     category: 'Workshop', 
     img: './img/gallery/Picture2.jpg',
     },

         { id: 22, 
     category: 'Workshop', 
     img: './img/gallery/Picture3.jpg',
     },

    { id: 23, 
     category: 'Workshop', 
     img: './img/gallery/Picture4.jpg',
     },

         { id: 24, 
     category: 'Workshop', 
     img: './img/gallery/Picture5.jpg',
     },


         { id: 25, 
     category: 'Workshop', 
     img: './img/gallery/Picture6.jpg',
     },


        { id: 26, 
     category: 'Workshop', 
     img: './img/gallery/Picture7.jpg',
     },

        { id: 27, 
     category: 'Workshop', 
     img: './img/gallery/Picture8.jpg',
     },

     
  ]);
  
  export { getDataGallery };
  