const getDataService = () => ([
     { id: 1, 
      judul: 'Manufacture Pallet', 
      img: './img/service/photo1.jpg',
      text: 'Mensuplai palet kayu dan pallet plastik ukuran standard maupun custom' 
    },


    { id: 2, 
      judul: 'Rental Pallet', 
      img: './img/service/photo2.jpg',
      text: 'Menyewakan palet kayu, pallet plastik, pallet besi dengan skema sesuai karakteristik kebutuhan pelanggan' 
    },

    { id: 3,
           judul: 'Training Pallet Handling', 
       img: './img/service/photo4.jpg',
      text: 'Memberikan training pallet handling baik dari sisi materi dan on job training'
 
        },

    { id: 4, 
      judul: 'Repair Treatment Pallet', 
      img: './img/service/photo5.jpg',
      text: 'Menerima service/repair, treatment pallet sesuai dengan standard ISPM#15'
     },

     { id: 5, 
          
      judul: 'Pallet Managemant System',
      img: './img/service/photo3.jpg', 
      text: 'Memastikan ketersediaan pallet dan menjaga kualitas pallet tetap terjaga untuk kebutuhan produksi dan rantai pasokan distribusi product.' 
  
     },

 
  ]);
  
  export { getDataService};
  