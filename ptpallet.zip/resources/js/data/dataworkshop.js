const getDataWorkshop = () => ([
     { id: 1, 
      judul: 'Workshop Banten', 
      alamat: 'Jalan Haredang Pamarayan KM 03 Pasirlimus Pamarayan Pudar Serang Banten 42176' 
    },


    { id: 2, 
      judul: 'WORKSHOP BALI', 
      alamat: 'Dusun Serongga Pondok, Desa Pangkungkarung,  Kecamatan Kerambitan, Tabanan , Bali'
    },

    { id: 3,
    judul: 'WORKSHOP  PASURUAN', 
      alamat: 'JL.Ponpes Terpadu Al Yasini Permas Sambisirah Kec Wonorejo Pasuruan Jawa timur'
       },

    { id: 4, 
      judul: 'WORKSHOP GROBOGAN', 
      alamat: 'Daplang Mangunsari RT.01 RW.01 Desa Tegowanu Kulon Kec Tegowanu Kab. Grobogan Jawa Tengah'
     },

     { id: 5, 
          
       judul: 'WORKSHOP BOGOR', 
      alamat: 'JL. Bantar Jati Citeureup Kab Bogor'
      },

    { id: 6, 
          
       judul: 'WORKSHOP  LAMPUNG', 
      alamat: 'Jl. Puskes lama Desa Tekad Kec Pulau Panggung Kab Tenggamus '
      },
 
  ]);
  
  export { getDataWorkshop };
  